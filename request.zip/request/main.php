<?php
    if(!isset($_COOKIE['Id'])){
        header("Location: login.php");
        exit;
    }

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Request</title>
</head>
<body>
<header>
<div class="container">
    <div ><img src="unitedlogo.gif"></div>
   <ul class = "nav">
       <!--<li><a href="new_form.php">request</a></li>-->
       <li><a href="view.php">view</a></li>
       <li><a href="signout.php">Sign Out</a></li>
   </ul>

</div>
 <div class="welcome">
     <h1>We are united</h1>
    </div>
</header>
    
</body>
</html>