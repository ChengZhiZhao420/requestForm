<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="new_form.css">
    <title>file and all</title>
</head>

<body>
    <div class="container">
        <div class="content">
            <div class="text">
                <p>Fill out Form</p>
            </div>

            <form action="new_form_fill.php" method="post" enctype="multipart/form-data" class="grid_con">
                <div class="input1">
                    <label for="option_request">Option:</label>
                    <select name="option">
                        <option value="request">Request</option>
                        <option value="Incident">Incident</option>
                    </select>
                </div>
                <div class="input1">
                    <label for="Areas">Areas:</label>
                    <select name="option2">
                        <?php
                        include "database.php";
                        $q = "select * from roles";
                        $result = $conn->query($q);

                        while ($row = $result->fetch_assoc()) {
                            $string = strtok($row['DESCRIPTION'], '/');
                            echo "<option value={$row['DESCRIPTION']}>$string</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="input1">
                    Name: <input type="text" name="name">
                </div>
                <div class="input1">
                    Phone: <input type="text" name="phone">
                </div>
                <div class="input1">
                    Description:<textarea id="" name="description" rows="4" cols="50"></textarea>
                </div>
                <div class="input1">
                    Email: <input type="email" name="email" pattern="[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}" required>
                </div>
                <div class="input1">
                    <input type="submit" name="submit_form">
                </div>
                <div class="input1">
                    File(PDF, TXT, IMAGE ONLY): <input type="file" name="new_file">
                </div>
            </form>


        </div>
    </div>

</body>

</html>