<?php

if($_POST['option']&&$_POST['option2']&&$_POST['name']&&
 $_POST['phone']&&$_POST['email']&&$_POST['description']&&$_POST['submit_form']){

    $option = $_POST['option'];
    $option2 = $_POST['option2'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $description = $_POST['description'];

    echo $option."\n";
    echo $option2."\n";
    echo $name."\n";
    echo $phone."\n";
    echo $email."\n";
    echo $description."\n";

}


?>