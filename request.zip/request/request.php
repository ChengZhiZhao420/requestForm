<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="request.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
    
    <title>Request Form</title>
</head>
<body>
    <div class="container">
        <div class="content">
           <div class="text">
                <h1>Request Form</h1>
            </div>
           <form action="fill.php" method="post">
           
           <div class="input">
                Request: <input type="text" name="request_name">
            </div>
            <div class="input">
                Name: <input type="text" name="employee_name">
            </div>
            <div class="input">
            <p><label for="description">Description:</label></p>    
            <textarea id="" name="description" rows="4" cols="50"></textarea>
            </div>
            <div class="input">
                Importance: <br>
               Asap <input type="radio" name="radio" value="Asap">
               Medium <input type="radio" name="radio" value="medium">
               can wait <input type="radio" name="radio" value="low">
            </div>
            <div class="input">
                <input type="submit" name="submit_request">
            </div>
           </form> 
            
        </div>
    </div>
    
</body>
</html>

