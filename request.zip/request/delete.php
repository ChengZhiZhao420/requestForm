<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
   <title>delete</title>
</head>

<body>

</body>

</html>

<?php
include "database.php";


if ($_GET['delete']) {

   $id = $_GET['delete'];
   echo $id;
   $query1 = "DELETE FROM form WHERE request_Id = '$id'";

   mysqli_query($conn, $query1);

   echo "<script>swal({
      title: '<p>Successfully!</p>',
      text: 'request deleted',
      type: 'success',
      timer: 1500,
      showConfirmButton:false
      })</script>";

   header("Refresh:2 , url = ./view.php");
}




?>