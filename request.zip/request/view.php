<?php
    if(!isset($_COOKIE['Id'])){
        header("Location: login.php");
        exit;
    }

?>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
   <title>View</title>
</head>

<body>
   <div class="header">
      <p>View Request Page</p>
   </div>

   <!-- Modal -->
   <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalLabel">Update Status</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <form action="update.php" method="post">

               <div class="modal-body">

                  <input type="hidden" name="update_id" id="update_id">

                  <div class="form-group">
                     <!--<label> status </label>
                  <input type="text" name="option" id="option" class="form-control"
                  placeholder="change state">-->
                     <select name="option" id="option" class="form-control">
                        <option name="option" id="option" value="Active">Active</option>
                        <option name="option" id="option" value="Done">Done</option>
                     </select>
                  </div>

                  <!--<select name = "option" id="option" >
                 <option   name ="option" id= "option"  value ="Active">Active</option>
                 <option  name = "option" id = "option" value = "Done">Done</option>
            </select>-->
                  <!--Active <input type="radio" name="option" value="Active">
               Done <input type="radio" name="option" value="Done">-->
               </div>

               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" name="update1" class="btn btn-info">save</button>
               </div>

            </form>

         </div>
      </div>
   </div>

   <div class="content justify-content-center">
      <table>
         <thread>

            <t>
               <th>Request</th>
               <th>Area</th>
               <th>Name</th>
               <th>Email</th>
               <th>Phone</th>
               <th>Description</th>
               <th>File</th>
               <th>Status</th>
               <th colspan="5">Action</th>
            </t>
         </thread>

         <?php

         include "database.php";

         $query = "SELECT * FROM form  WHERE Area = '{$_COOKIE['Id_roll']}'";
         $result = mysqli_query($conn, $query);

         while ($row = $result->fetch_assoc()) {
            $id = $row['request_Id'];
            $r_name = $row['request_Name'];
            $a_name = $row['Area'];
            $e_name = $row['requester_Name'];
            $phone = $row['phone'];
            $email = $row['email'];
            $d_name = $row['Description'];
            $file = $row['file'];
            $status = $row['Status'] ?>

            <tr style="background-color:black;">
               <td><?php echo $id ?></td>
               <td><?php echo $a_name  ?></td>
               <td><?php echo $e_name  ?></td>
               <td><?php echo $email  ?></td>
               <td><?php echo $phone  ?></td>
               <td><textarea style="background-color:black;" name="" id="" cols="25" rows="5"><?php echo $d_name  ?></textarea></td>
               <?php
               if ($file == "uploads/") {
                  $file = "";
               ?>
                  <td><?php echo $file ?></td>
               <?php
               } else {
                  $new = substr(strstr($file, '/'), 1);
               ?>

                  <td><a href=<?php echo $file ?> target="_blank"><?php echo $new ?></td>

               <?php
               }
               ?>
               <?php
               if ($status == "Active") { ?>
                  <td style="background-color:red;"><?php echo $status ?></td>
               <?php



               } else { ?>
                  <td style="background-color:green;"><?php echo $status ?></td>
               <?php
               }
               ?>


               <td>
                  <button type="button" class="btn btn-primary updtbtn">
                     Update
                  </button>
                  <!--<a href="update.php?update=<?php //echo $id;
                                                   ?>"
           class = "btn btn-info">Update</a>-->

                  <a href="delete.php?delete=<?php echo $id; ?>" class="btn btn-danger"><img src="trash.png" width="20px" height="30px"></a>
               </td>
            </tr>


         <?php
         }
         ?>
      </table>

   </div>
   <div>
      <a href="main.php"><input style="background-color:darkorange;" type="button" value="Go Back"></a>
   </div>
   <div class="footer">
      <h6 style="font-size:10px;">UNITED LEGWEAR & APPAREL CO. © 2021 ALL RIGHTS RESERVED</h6>
   </div>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

   <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
   <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
   <script>
      $(document).ready(function() {

         $('.updtbtn').on('click', function() {

            $('#updateModal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
               return $(this).text();
            }).get();

            console.log(data);

            $('#update_id').val(data[0]);
            $('#option').val(data[8]);
            // $('#lname').val(data[2]);
            //$('#course').val(data[3]);
            //$('#contact').val(data[4]);
         });
      });
   </script>
</body>

</html>
<style>
   * {
      font-family: Verdana, Geneva, Tahoma, sans-serif;
   }

   table th,
   td {
      border: 2px solid white;
      width: 145px;
      box-sizing: 50px;
      height: 45px;
      color: #fff;
      border-radius: 4px;
   }

   table {
      font-size: 12px;
      color: black;
      margin-top: 10px;
   }

   .content {
      justify-content: center;
      display: flex;

   }

   .danger {
      width: 65px;
      height: 40px;
      border-radius: 5px;
   }

   .danger:hover {
      background-color: red;
   }

   a:hover {
      background-color: black;
   }

   a {
      margin-left: 10px;
      margin-top: 5px;
      display: inline-block;
      color: #fff;
      font-family: Verdana, Geneva, Tahoma, sans-serif;
   }

   h1 {
      color: #fff;
      text-align: center;
   }

   body {
      background-color: black;
   }

   .header {
      background-color: darkorange;
      width: 99.5%;
      height: 40px;
      border-radius: 4px;

   }

   p {
      text-align: center;
      font-family: Verdana, Geneva, Tahoma, sans-serif;
      margin-top: 20px;
      font-size: 20px;
   }

   table th {
      color: black;
      background-color: darkorange;
   }

   textarea {
      color: #fff;
   }

   tr:hover td {
      background-color: darkorange;
   }

   input {
      cursor: pointer;
      height: 50px;
      width: 100;
      border-radius: 4px;
   }

   .footer {
      color: black;
      font-size: 5px;
      margin-top: 400px;
      text-align: center;
      background-color: darkorange;
      border-radius: 4px;
      height: 25px;
      padding: 5px;

   }
</style>