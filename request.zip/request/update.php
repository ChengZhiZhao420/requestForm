<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
    <title>Update</title>
</head>

<body>

</body>

<?php
include "database.php";
include "mail.php";

if (isset($_POST['update1'])) {

    $id = $_POST['update_id'];
    $status = $_POST['option'];

    $query = "UPDATE form SET Status = '$status' WHERE request_Id = '$id'";
    $query1  = "SELECT email, request_Id FROM form WHERE request_Id = '$id'";

    if (mysqli_query($conn, $query)) {
        $result = $conn->query($query1)->fetch_assoc();

        $mail->setFrom('jhosuecruz28@gmail.com', 'Mailer');
        $mail->addAddress($result['email']);
        $mail->isHTML(true);
        
        if ($status == "Done") {
            $subject = "Request Done";
            $body = '<p style=font-size:25px;>Request ID ' . $result['request_Id'] . ' is done</p>';
        } else if ($status == "Active") {
            $subject = "Request Reactive";
            $body = '<p style=font-size:25px;>Request ID ' . $result['request_Id'] . ' is reactive</p>';
        }
        $mail->Subject = $subject;
        $mail->Body    = $body;

        echo $mail->send();

        echo "<script>swal({
                title: '<p>Successfull!</p>',
                text: 'Status Updated',
                type: 'success',
                timer: 1500,
                showConfirmButton:false
                })</script>";

        header("Refresh:2 , url = ./view.php");
    } else {
        echo "<script>swal({
                title: '<p>Wrong</p>',
                text: 'connection error',
                type: 'error',
                timer: 1500,
                showConfirmButton:false
                })</script>";

        header("Refresh:2 , url = ./view.php");
    }
}
?>

</html>