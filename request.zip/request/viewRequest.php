<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="viewRequest.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Document</title>
</head>

<body class="body1">
    <?php
    include "database.php";
    $id = isset($_GET['request_id']) ? $_GET['request_id'] : 0;
    $q = "SELECT * FROM form WHERE request_Id = '$id'";
    $result = $conn->query($q)->fetch_assoc();

    ?>
    <div class="container1">
        <div class="content1">
            <div class="text">
                <p><?php echo "Request# {$_GET['request_id']}" ?></p>
            </div>
            <hr>
            <p>
                <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Button with data-target
                </button>
            </p>
            <div class="collapse" id="collapseExample">
                <div class="card card-body">
                    <table style="color:black">
                        
                    </table>
                </div>
            </div>
            <hr>
            <form action="<?php
                            if (isset($_POST['enter'])) {
                                $requestType = $_POST['option'];
                                $requestArea = $_POST['option2'];
                                $name = $_POST['name'];
                                $description = $_POST['description'];
                                $phone = $_POST['phone'];
                                $email = $_POST['email'];

                                $q = "UPDATE form SET request_Name = '$requestType', Area = '$requestArea', requester_Name = '$name', email = '$email', phone = '$phone', Description = '$description' WHERE request_Id = '{$_GET['request_id']}'";
                                if ($conn->query($q)) {
                                    header("Refresh:2");
                                }
                            }
                            ?>" method="post" enctype="multipart/form-data" class="grid_con">
                <div class="input1">
                    Option:<input type="text" name="temp" id="temp" value="<?php echo $result['request_Name'] ?>" disabled>
                    <select name="option" id="option" hidden>
                        <option value="request">Request</option>
                        <option value="Incident">Incident</option>
                    </select>
                </div>
                <div class="input1">
                    Area:<input type="text" name="temp1" id="temp1" value="<?php $string = strtok($result['Area'], '/'); echo $string;?>" disabled>
                </div>
                <div class="input1">
                    Name: <input id="name" type="text" name="name" value="<?php echo $result['requester_Name'] ?>" disabled>
                </div>
                <div class="input1">
                    Phone: <input id="phone" type="text" name="phone" value="<?php echo $result['phone'] ?>" disabled>
                </div>
                <div class="input1">
                    Description:<textarea id="description" name="description" rows="4" cols="50" disabled><?php echo $result['Description'] ?></textarea>
                </div>
                <div class="input1">
                    Email: <input id="email" type="email" name="email" value="<?php echo $result['email'] ?>" pattern="[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}" required disabled>
                </div>
                <div class="input1">
                    <input type="button" name="submit_form" value="Update" onclick="enableUpdate()" id="update">
                </div>
                <div class="input1">
                    <input type="submit" name="enter" value="Enter" hidden id="enter" hidden>
                </div>
                <!--<div class="input1">
                    File: <input type="file" name="new_file">
                </div>-->
            </form>

        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
        function enableUpdate() {
            var update = document.getElementById("update");
            if (update.value == 'Cancel') {
                update.value = 'Update';
                document.getElementById("enter").setAttribute("hidden", "");
                document.getElementById("option").hidden = true;
                document.getElementById("temp").hidden = false;
                document.getElementById("name").disabled = true;
                document.getElementById("description").disabled = true;
                document.getElementById("email").disabled = true;
                document.getElementById("phone").disabled = true;

            } else {
                update.value = 'Cancel';
                document.getElementById("enter").removeAttribute("hidden");
                document.getElementById("option").hidden = false;
                document.getElementById("temp").hidden = true;
                document.getElementById("name").disabled = false;
                document.getElementById("description").disabled = false;
                document.getElementById("email").disabled = false;
                document.getElementById("phone").disabled = false;

            }

        }
    </script>
</body>

</html>