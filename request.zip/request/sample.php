<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title" id="ModalLabel">EDIT ITEM</h1>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="main/update_ipreceiving.php" method="POST">
                        <div class="modal-body">                    
                            
                            <input type="hidden" id="ID_RECEIVING" name="ID_RECEIVING">                            
                            
                            <div class="form-group">
                                <label class="col-12"><h4>Container:</h4></label>
                                    <input type="text" id="CONTAINERNO" name="CONTAINERNO" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label id="SHIFT_ASSIGNED" class="col-12"><h4>Shift Assigned:</h4></label>
                                    <select class="form-control col-12" id="SHIFT_ASSIGNED" name="SHIFT_ASSIGNED" required>
                                        <option value="FIRST">FIRST</option>
                                        <option value="SECOND">SECOND</option>
                                        <option value="SCHEDULED">SCHEDULED</option>
                                        <option value="NOT ASSIGNED">NOT ASSIGNED</option>
                                    </select>   
                            </div>
                            <div class="form-group">
                                <label class="col-12"><h4>Pacer Drivers:</h4></label>
                                    <select class="form-control col-12" id="PACER_DRIVERS" name="PACER_DRIVERS" >
                                        <option value=""></option>
                                        <?php for ($i = 0; $i <= 10; $i++) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>   
                            </div> 
                            <div class="form-group">
                                <label class="col-12"><h4>Lumpers:</h4></label>
                                    <select class="form-control col-12" id="LUMPERS" name="LUMPERS" >
                                        <option value=""></option>
                                        <?php for ($i = 0; $i <= 10; $i++) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>  
                            </div>
                            <div class="form-group">
                                <label class="col-12"><h4>Scanners:</h4></label>
                                    <select class="form-control col-12" id="SCANNERS" name="SCANNERS" >
                                        <option value=""></option>
                                        <?php for ($i = 0; $i <= 10; $i++) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>  
                            </div> 
                            <div class="form-group">
                                <label class="label col-12"><h4>Cubic Scan:</h4></label>
                                    <select class="form-control col-12" id="CUBIC_SCAN" name="CUBIC_SCAN" >
                                        <option value=""></option>
                                        <?php for ($i = 0; $i <= 10; $i++) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>  
                            </div> 
                            <div class="form-group">
                                <label class="label col-12">Comments:</label>                        
    					            <textarea type="text" name="COMMENTS2" id="COMMENTS2" rows=5 class="textarea" style="text-transform:uppercase"></textarea>
                            </div> 
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="updatedata" class="btn btn-primary">Save Changes</button>
                        </div>     
                                                           
                    </form>
                </div>
            </div>
        </div>     



<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>            	
    <script src="js/alertifyjs/script.js"></script>
    <script src="https://cdn.datatables.net/plug-ins/1.10.20/api/sum().js"></script><script src="path/to/jquery.js"></script>
    <script src="js/alertifyjs/alertify.js"></script>
    
</body>
</html>


<?php
/*echo "hello this is my first web page";

$x =5;
$y = 2;

$z = $x + $y;

echo "<br>the sum is: ".$z;

$var = "it is not raining";

if($var == "it is raining"){
    echo "<br>it is in fact raining";

}else{
    echo "<br>it is not raining";
}*/

?>
