<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
    <title>Document</title>
</head>

<body>

</body>

</html>

<?php
include "database.php";

if (
    isset($_POST['option']) && isset($_POST['option2']) && isset($_POST['name']) &&
    isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['description']) && isset($_POST['submit_form'])
) {
    $date = time();
    $r_name = $_POST['option'];
    $a_name = $_POST['option2'];
    $e_name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $d_name = $_POST['description'];
    $file = $_FILES['new_file'];
    $status = "Active";
    $id = substr(strrchr($a_name, '/'), 1) . $date;
    $upload = false;

    if (isset($_FILES['new_file'])) {

        $target = "uploads/";
        $file = $_FILES['new_file']['name'];
        $fileTarget = $target . $file;
        $fileName = $_FILES['new_file']['tmp_name'];

        if (!empty($_FILES["new_file"]["size"])) {
            if (($_FILES["new_file"]["type"] == "application/pdf")
                || (preg_match("/^image/", $_FILES["new_file"]["type"]) == 1)
                || ($_FILES["new_file"]["type"] == "application/doc")
                || ($_FILES["new_file"]["type"] == "text/plain")
                && ($_FILES["new_file"]["size"] < 200000
                )
            ) {
                $result = move_uploaded_file($fileName, $fileTarget);
                if ($result) {
                    echo "file uploaded corretly";
                    $upload = true;
                }
            }
        }else{
            $fileTarget = null;
            $nofile = true;
        }
    }

    if ($upload || $nofile) {
        $query = "INSERT INTO form (request_Name,Area,requester_Name,email,phone,Description,file,Status,request_Id) 
       VALUES('$r_name','$a_name','$e_name','$email','$phone', '$d_name','$fileTarget','$status', '$id')";
        $query1 = "SELECT email FROM person WHERE Id_roll = '$a_name'";
        $result = $conn->query($query1);

        if (mysqli_query($conn, $query)) {
            while ($row = $result->fetch_assoc()) {
                $tempEmail = $row['email'];
                sentMail($tempEmail, $d_name, $phone, $email, $fileTarget, 1);
            }

            sentMail($email, $id, $a_name, null, null, 2);

            echo "<script>swal({
            title: '<p>Successfully!</p>',
            text: 'Request submitted',
             type: 'success',
             timer: 1500,
             showConfirmButton:false
            })</script>";

            header("Refresh:2 , url = ./viewRequest.php?request_id=$id");
        }
    } else {
        echo "<script>swal({
            title: '<p>Failed!</p>',
            text: 'File Type Need To Be PDF, TXT, IMAGE',
             type: 'error',
             timer: 1500,
             showConfirmButton:false
            })</script>";

        header("Refresh:2 , url = ./new_form.php");
    }
}

function sentMail($recipentEmail, $request, $requesterPhone, $requesterEmail, $attachFile, $count)
{
    include "mail.php";
    $mail->setFrom('jhosuecruz28@gmail.com', 'Mailer');
    $mail->addAddress($recipentEmail);

    $mail->isHTML(true);
    if ($count == 1) {
        $subject = 'Order Request';
        $body = '<p style=font-size:25px;>' . $request . '<br><br>
                Contact Phone: ' . $requesterPhone . '<br><br>Contact Email: ' . $requesterEmail . '</p>';
    } else {
        $subject = 'Requested Successfully!';
        $body = '<p style=font-size:15px;>Thanks for contacting us! We have received your request, and we\'ll get back to you as soon as possible. <br><br>

        <b>PLEASE DO NOT REPLY TO THIS EMAIL</b> if you would like to add additional information or contribute more to your support request. Replying directly to this email enables us to keep all case-related correspondence together and serve you more efficiently.<br><br>
        
        If you have any additional requests or questions outside the original request, please raise a new case.<br><br>
        
        Sincerely,<br>
        Aptean Customer Support<br><br>
        
        
        Case #: ' . $request . ' <br>
        Case Subject: ' . $requesterPhone . ' Locations <br>
        Customer Reference: <br>
        To view your case or update your information, <a href=http://localhost/request/viewRequest.php?request_id=' . $request . '>click here</a>.<br>
         </p>';
    }
    $mail->Subject = $subject;
    $mail->Body    = $body;
    $mail->AltBody = 'new request added';
    if ($attachFile != null) {
        $mail->addAttachment($attachFile);
    }
    $mail->send();
}
?>