<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="register.css">
    <title>Document</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>

</head>

<body>
    <div class="footer">
        <h1>Sign up</h1>
    </div>
    <div class="masterCon">
        <div class="subCon">
            <form action="" method="post">
                <div class="item">
                    NAME: <input type="text" name="name" required>
                </div>
                <div class="item">
                    ID: <input type="text" name="ID" required>
                </div>
                <div class="item">
                    ID ROLE: <select name="ID_Rol">
                        <?php
                        include "database.php";
                        $q = "select * from roles";
                        $result = $conn->query($q);

                        while ($row = $result->fetch_assoc()) {
                            $string = strtok($row['DESCRIPTION'], '/');
                            echo "<option>$string</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="item">
                    Email: <input type="text" name="email" required>
                </div>
                <div class="sizedBox"></div>
                <input type="submit" value="Sign Up" name="signup">
                <a href="login.php"><input type="button" value="Cancel"></a>
            </form>
        </div>
    </div>
    <?php
    if (isset($_POST['signup'])) {
        if (!empty($_POST['name']) && !empty($_POST['ID_Rol']) && !empty($_POST['email']) && !empty($_POST['ID'])) {
            $query = "insert into person (Name, Id_roll, email, Id) values('{$_POST['name']}', '{$_POST['ID_Rol']}', '{$_POST['email']}', '{$_POST['ID']}')";
            $query1 = "SELECT COUNT(*) as c FROM person where Id = '{$_POST['ID']}'";
            $result = $conn->query($query1)->fetch_assoc();

            if ($result['c'] == 0) {
                if ($conn->query($query)) {
    ?>
                    <script>
                        swal({
                            title: 'Successfully!',
                            text: 'Create Account Successfully',
                            type: 'success',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    </script>
                <?php
                    header('Refresh:2 , url = login.php');
                }
            } else {
                ?>
                <script>
                    swal({
                        title: 'Failed!',
                        text: 'Please Use Another ID',
                        type: 'error',
                        timer: 1500,
                    });
                </script>
    <?php
            }
        }
    }

    ?>
</body>

</html>