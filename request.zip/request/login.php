<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
    <title>Login</title>
</head>
<body>
 
<div class="header">
    <h1 >login</h1>
</div>

<div class="container">
    <div class = "content">
       <h1>Login</h1>
          <form action="" method="post">
                <div>
                    <p> Id: <input type = "text" name="Id" placeholder="id"></p>
                </div>
                <div>
                    <input type = "submit" name="submit">
                </div>
         </form>
         <form action="register.php" method="post">
             <input type="submit" value="Sign Up">
         </form>
   </div>


           
     

</div>
    
</body>
</html>


<?php
    include "database.php";

    if($_POST['Id'] && $_POST['submit']){

        $query = "SELECT Id_roll FROM person WHERE Id = {$_POST['Id']} ";

        $result = mysqli_query($conn,$query);

        if($result){
            $q = $result->fetch_assoc();
            //open the session using the id
            setcookie('Id',$_POST['Id'], time() + (86400 * 30), "/");
            setcookie('Id_roll',$q['Id_roll'], time() + (86400 * 30), "/");

            echo "<script>swal({
                title: '<p>Welcome!</p>',
                text: 'new session',
                type: 'success',
                timer: 1500,
                showConfirmButton:false
                })</script>";
          
                header("Refresh:2 , url = ./main.php");
            
        }else{
            echo "<script>swal({
                title: '<p>Invalid Id</p>',
                text: 'please povide a valid Id',
                type: 'error',
                timer: 1500,
                showConfirmButton:false
                })</script>";
          
                header("Refresh:2 , url = ./login.php");
            

        }

    }
?>