<?php
if(isset($_POST['submit'])){
    $target = "uploads/";
    $file = $_FILES['file']['name'];
    $fileTarget = $target.$file;
    $fileName = $_FILES['file']['tmp_name'];   
    $type = $_FILES["file"]["type"];

    echo $type;

    if (($_FILES["file"]["type"] == "application/pdf")
    || (preg_match("/^image/", $_FILES["file"]["type"]) == 1)
    || ($_FILES["file"]["type"] == "application/doc")
    || ($_FILES["file"]["type"] == "text/plain")
    && ($_FILES["file"]["size"] < 200000)){
        echo $_FILES["file"]["type"];
        $result = move_uploaded_file($fileName, $fileTarget);
        if($result){
            echo "file uploaded corretly";
        }else{
            echo "not possible";
        }
    }
}
?>