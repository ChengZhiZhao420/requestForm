<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbName = "request";
$conn =  new mysqli($host, $user, $pass, $dbName);

mysqli_query($conn, "SET NAMES 'utf8mb4'");
if ($conn->connect_error) {
    die("Database Error: {$conn->connect_error}");
} else {
    //echo "Success";
}
?>